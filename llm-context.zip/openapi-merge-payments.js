// placeholder: scripts\openapi-merge-payments.js
