// placeholder: src\payments\registry.ts
