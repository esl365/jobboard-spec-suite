<!-- placeholder: docs\llm-input-pack\Part3A_Payments_Adapter_Contract.md -->
