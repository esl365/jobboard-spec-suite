<!-- placeholder: scripts\pack-llm-context.sh -->
