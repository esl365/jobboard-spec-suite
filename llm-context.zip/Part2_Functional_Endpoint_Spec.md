<!-- placeholder: docs\llm-input-pack\Part2_Functional_Endpoint_Spec.md -->
