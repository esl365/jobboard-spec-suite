// placeholder: src\payments\adapters\mock.ts
