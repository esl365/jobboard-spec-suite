// placeholder: scripts\scan-forbidden.js
